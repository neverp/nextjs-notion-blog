module.exports = {
  // where it all starts -- the site's root Notion page (required)
  rootNotionPageId: '你的页面地址',

  // if you want to restrict pages to a single notion workspace (optional)
  // (this should be a Notion ID; see the docs for how to extract this)
  rootNotionSpaceId: "你的地址",

  // basic site info (required)
  name: 'XXX的博客',
  domain: '你的域名',
  author: '你的名字',

  // open graph metadata (optional)
  description: '笔记、博客',
  socialImageTitle: 'xxx的博客',
  socialImageSubtitle: '👋',

  // social usernames (optional)
  twitter: '联系方式，可以为空',
  github: '联系方式，可以为空',
  linkedin: '联系方式，可以为空',

  // default notion icon and cover images for site-wide consistency (optional)
  // page-specific values will override these site-wide defaults
  defaultPageIcon: null,
  defaultPageCover: null,
  defaultPageCoverPosition: 0.5,

  // image CDN host to proxy all image requests through (optional)
  // NOTE: this requires you to set up an external image proxy
  imageCDNHost: null,

  // Utteranc.es comments via GitHub issue comments (optional)
  utterancesGitHubRepo: "null",

  // whether or not to enable support for LQIP preview images (optional)
  // NOTE: this requires you to set up Google Firebase and add the environment
  // variables specified in .env.example
  isPreviewImageSupportEnabled: false,

  // map of notion page IDs to URL paths (optional)
  // any pages defined here will override their default URL paths
  // example:
  //
  // pageUrlOverrides: {
  //   '/foo': '067dd719a912471ea9a3ac10710e7fdf',
  //   '/bar': '0be6efce9daf42688f65c76b89f8eb27'
  // }
  pageUrlOverrides: null
}